<?php 
namespace sia\components;

require "components/studHome.php";