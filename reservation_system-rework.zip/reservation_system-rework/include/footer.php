
<style>

footer {
            background-color: #990f02;
            padding: 10px;
            color: white;
            position: fixed;
            bottom: 0;
            width: 100%;
            text-align: center;
            height: 80px;
        }
</style>

</body>
<footer>
        &copy; Group 2. All Rights Reserved.
    </footer>
</html>